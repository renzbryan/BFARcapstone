

<?php $__env->startSection('title', 'View Stock'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

<?php $__env->startSection('content'); ?>
<div class="grid w-full gap-6 p-20 ml-36 pl-24 mx-auto font-nunito">
    <div class="flex gap-2">
        <a class="w-fit bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 active:bg-green-800" href="<?php echo e(route('iar.index')); ?>">Go to IAR</a>
    </div>

    <div class="mb-4">
        <input type="text" id="searchInput" class="form-control p-2 border rounded" placeholder="Search Stock...">
    </div>
  
    <h1 class="text-3xl font-bold mb-6">Property Card</h1>
  
    
    <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-6">
        <?php $__currentLoopData = $propertyEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full md:w-1/2 border-t-4 border-blue-900 bg-white p-6 rounded-md shadow-lg">
            <div class="card-body p-4">
                <!-- Display IAR details if available -->
                <?php if($item->iar): ?> <!-- Check if IAR ID is not null and relationship exists -->
    <p class="text-2xl font-semibold mb-2"><strong><?php echo e($item->iar->iar_entityname); ?></strong></p>
    <p class="text-lg mb-2"><strong>Fund Cluster:</strong> <?php echo e($item->iar->iar_fundcluster); ?></p>
<?php else: ?>
    <p class="text-2xl font-semibold mb-2 text-red-500">No IAR Data Available</p>
<?php endif; ?>


                <p class="text-2xl font-semibold mb-2"><strong><?php echo e($item->name); ?></strong></p>
                <p class="text-lg mb-2">
                  <strong>Quantity:</strong> <?php echo e($item->quantity); ?> <?php echo e($item->unit); ?>

                </p>


                <!-- Action buttons -->
                <div class="action-column mt-4">
                <a class="btn btn-primary bg-[#3a5998] text-white border-[#3a5998] rounded px-4 py-2 hover:bg-[#0056b3] hover:border-[#0056b3]" href="<?php echo e(route('pcitems.show', $item['id'])); ?>">View</a>
<a class="btn btn-warning bg-[#ffc107] text-white border-[#ffc107] rounded px-4 py-2 hover:bg-[#e0a800] hover:border-[#e0a800]" href="<?php echo e(route('pcitems.create', $item['id'])); ?>">Edit</a>

                    <a class="btn btn-danger bg-[#ff5ca1] text-white border-[#ff5ca1] rounded px-4 py-2 hover:bg-[#c82333] hover:border-[#c82333]" href="">Delete</a>
                </div>

                <!-- Comments section -->
                <div class="comments-section mt-4">
                    <h5 class="text-xl font-semibold mb-2">Comments</h5>
                    <?php if(empty($item->comments)): ?>
                        <p>No comments yet.</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $item->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment mb-2">
                                <p><strong><?php echo e($comment->user->name); ?>:</strong> <?php echo e($comment->content); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php if(auth()->user()->is_admin): ?>
                        <form action="<?php echo e(route('comments.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="commentable_id" value="<?php echo e($item->id); ?>">
                            <input type="hidden" name="commentable_type" value="App\Models\PropertyItem">
                            <div class="form-group">
                                <textarea name="content" class="form-control p-2 border rounded" placeholder="Add a comment" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary bg-[#3a5998] text-white border-[#3a5998] rounded px-4 py-2 mt-2 hover:bg-[#0056b3] hover:border-[#0056b3]">Add Comment</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sample\resources\views/admin/property/view-property.blade.php ENDPATH**/ ?>