

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4 mt-8 ml-48 lg:p-12 font-nunito">
    <header class="mb-8">
        <div class="flex space-x-4 mb-4">
            <button class="bg-red-500 text-white py-2 px-4 rounded-md shadow-sm hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500" onclick="window.history.back()">← Back</button>
        </div>
    </header>

    <?php if($stockEntry): ?> <!-- Check if stockEntry is not null -->
        <div class="bg-white border-t-4 border-blue-900 shadow-lg rounded-lg p-8 mb-8">
            <h2 class="text-xl font-semibold mb-4">STOCK CARD</h2>
            
            <!-- Displaying details -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <p class="text-gray-700 font-semibold"><strong>Entity Name:</strong> <?php echo e($stockEntry->iar_entityname); ?></p>
                    <p class="text-gray-700 font-semibold"><strong>Stock Name:</strong> <?php echo e($stockEntry->stock_name); ?></p>
                    <p class="text-gray-700 font-semibold"><strong>Quantity:</strong> <?php echo e($stockEntry->quantity); ?></p>
                    <p class="text-gray-700 font-semibold"><strong>Description:</strong> <?php echo e($stockEntry->description); ?></p>
                    <p class="text-gray-700 font-semibold"><strong>Unit of Measurement:</strong> <?php echo e($stockEntry->unit); ?></p>
                </div>
                <div>
                    <p class="text-gray-700 font-semibold"><strong>Fund Cluster:</strong> <?php echo e($stockEntry->iar_fundcluster); ?></p>   
                    <p class="text-gray-700 font-semibold"><strong>Stock No.:</strong> <?php echo e($stockEntry->stocks_id); ?></p> 
                    <p class="text-gray-700 font-semibold"><strong>Reorder Point:</strong> <?php echo e($stockEntry->reorder_point); ?></p> 
                </div>
            </div>
        </div>

        <!-- Optional section for additional stock entry details -->
        <div class="bg-white border-t-4 border-blue-900 shadow-lg rounded-lg p-8">
            <h2 class="text-xl font-semibold mb-4">Transaction History</h2>
            <form id="transferForm">
                <table class="min-w-full bg-white border border-gray-300 rounded-md">
                    <thead class="bg-gray-200 text-gray-700">
                        <tr>
                            <th>Date</th>
                            <th>Reference</th>
                            <th>Receipt Qty</th>
                            <th>Issue Qty</th>
                            <th>Issue Office</th>
                            <th>Balance Qty</th>
                            <th>No. of days to Consume</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($stockEntry->date); ?></td>
                            <td><?php echo e($stockEntry->reference); ?></td>
                            <td><?php echo e($stockEntry->receipt_qty); ?></td>
                            <td><?php echo e($stockEntry->issue_qty); ?></td>
                            <td><?php echo e($stockEntry->issue_office); ?></td>
                            <td><?php echo e($stockEntry->balance_qty); ?></td>
                            <td><?php echo e($stockEntry->consume); ?></td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    <?php else: ?>
        <p class="text-red-500">No stock entry found.</p>
    <?php endif; ?>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
<script src="https://cdn.tailwindcss.com"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u127431254/domains/e-prbfar.online/public_html/resources/views/admin/scitems/view-scitems.blade.php ENDPATH**/ ?>