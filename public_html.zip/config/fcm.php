<?php

return [
    'server_key' => env('FCM_SERVER_KEY'),
    'sender_id' => env('496147153354'),
];



